CARNIVAL BALL DROP WEBSITE

Files:
- index.html
- styles.css
- script.js

How to use:
1. Extract the ZIP folder.
2. Open index.html in your browser.
3. For development, open the folder in Visual Studio Code and use Live Server.
4. Upload all three files together to Netlify or GitHub Pages.

Features:
- Three animated balls
- Six equal random outcomes per ball
- Responsive mobile layout
- Idle machine animations
- Drop sounds made with Web Audio (no audio files needed)
- Result history
- Double and triple celebrations
- No betting, balances, payouts, odds, or real-money features


FAIR PHYSICS MODE
- Balls continuously move in the holder while idle.
- Clicking the button accelerates the holder for a secure-random duration.
- All three balls release simultaneously from their visible positions.
- Matter.js physics determines the final slot.
- No result is selected before the balls land.


AUDIO UPDATE
- No machine idle sound is used.
- machine_boost.mp3 plays only after DROP THE BALLS is clicked.
- The release waits for the boost sound to finish naturally, so it is not cut off.
