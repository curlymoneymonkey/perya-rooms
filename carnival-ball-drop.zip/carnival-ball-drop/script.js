(() => {
  'use strict';

  const dropButton = document.getElementById('dropButton');
  const soundToggle = document.getElementById('soundToggle');
  const clearHistoryButton = document.getElementById('clearHistory');
  const machineStatus = document.getElementById('machineStatus');
  const roundLabel = document.getElementById('roundLabel');
  const historyList = document.getElementById('historyList');
  const mixerSection = document.querySelector('.mixer-section');
  const ballHolder = document.getElementById('ballHolder');
  const holderBalls = [...document.querySelectorAll('.idle-ball')];
  const resultColumns = [...document.querySelectorAll('.result-column')];
  const canvas = document.getElementById('physicsCanvas');
  const physicsWrap = document.getElementById('physicsWrap');

  let soundOn = true;
  let isRunning = false;
  let round = 1;
  let history = [];
  let mixerAnimationId = 0;
  let holderState = [];
  let mixerMode = 'idle';
  let mixerLoopStarted = false;
  let engine;
  let render;
  let runner;
  let worldWidth = 800;
  let worldHeight = 600;
  let activeBalls = new Map();
  let completedCount = 0;
  let currentOutcomes = { A: null, B: null, C: null };
  let collisionCooldown = new WeakMap();

  const sfx = {
    boost: new Audio('sounds/machine_boost.mp3'),
    gate: new Audio('sounds/gate_open.wav'),
    roll: new Audio('sounds/ball_roll.wav'),
    ding: new Audio('sounds/result_ding.wav'),
    pegs: Array.from({ length: 6 }, (_, index) => new Audio(`sounds/peg_hit_${index + 1}.wav`))
  };
    sfx.boost.volume = .72;
  sfx.gate.volume = .7;
  sfx.roll.volume = .45;
  sfx.ding.volume = .65;
  sfx.pegs.forEach(audio => audio.volume = .22);

  function play(audio, restart = true) {
    if (!soundOn) return;
    try {
      if (restart) audio.currentTime = 0;
      const promise = audio.play();
      if (promise?.catch) promise.catch(() => {});
    } catch (_) {}
  }

  function stop(audio) {
    audio.pause();
    audio.currentTime = 0;
  }

  function playBoostAndWait() {
    if (!soundOn) {
      return wait(950);
    }

    stop(sfx.boost);

    return new Promise(resolve => {
      let resolved = false;

      const finish = () => {
        if (resolved) return;
        resolved = true;
        sfx.boost.removeEventListener('ended', finish);
        resolve();
      };

      sfx.boost.addEventListener('ended', finish, { once: true });
      const promise = sfx.boost.play();

      if (promise?.catch) {
        promise.catch(() => {
          setTimeout(finish, 950);
        });
      }

      // Safety fallback in case the browser never emits "ended".
      setTimeout(finish, Math.max(950, sfx.boost.duration * 1000 + 100 || 1150));
    });
  }

  function playPeg(speed) {
    if (!soundOn || speed < 2.2) return;
    const audio = sfx.pegs[Math.floor(Math.random() * sfx.pegs.length)].cloneNode();
    audio.volume = Math.min(.34, .08 + speed * .018);
    audio.playbackRate = .88 + Math.random() * .26;
    play(audio);
  }

  function secureRandom(min = 0, max = 1) {
    if (window.crypto?.getRandomValues) {
      const values = new Uint32Array(1);
      window.crypto.getRandomValues(values);
      return min + (values[0] / 4294967296) * (max - min);
    }
    return min + Math.random() * (max - min);
  }

  function secureChoice(array) {
    return array[Math.floor(secureRandom(0, array.length))];
  }

  function requireMatter() {
    if (!window.Matter) {
      machineStatus.textContent = 'Physics library failed to load';
      dropButton.disabled = true;
      return false;
    }
    return true;
  }

  function setupPhysics() {
    if (!requireMatter()) return;
    const { Engine, Render, Runner, Bodies, Composite, Events } = Matter;
    const rect = physicsWrap.getBoundingClientRect();
    worldWidth = Math.max(320, Math.round(rect.width));
    worldHeight = Math.max(390, Math.round(rect.height));
    canvas.width = worldWidth * Math.min(2, window.devicePixelRatio || 1);
    canvas.height = worldHeight * Math.min(2, window.devicePixelRatio || 1);

    if (render) {
      Render.stop(render);
      Runner.stop(runner);
      Composite.clear(engine.world, false);
      render.canvas.removeAttribute('style');
    }

    engine = Engine.create({ enableSleeping: false });
    engine.gravity.y = 1.16;
    engine.gravity.scale = 0.001;

    render = Render.create({
      canvas,
      engine,
      options: {
        width: worldWidth,
        height: worldHeight,
        wireframes: false,
        background: 'transparent',
        pixelRatio: Math.min(2, window.devicePixelRatio || 1)
      }
    });
    runner = Runner.create();

    const wallStyle = { fillStyle: 'rgba(255,255,255,.07)', strokeStyle: 'rgba(255,255,255,.22)', lineWidth: 1 };
    const pegStyle = { fillStyle: '#b9c7d0', strokeStyle: '#526470', lineWidth: 1 };
    const bodies = [];

    bodies.push(Bodies.rectangle(5, worldHeight / 2, 10, worldHeight, { isStatic: true, label: 'wall', render: wallStyle }));
    bodies.push(Bodies.rectangle(worldWidth - 5, worldHeight / 2, 10, worldHeight, { isStatic: true, label: 'wall', render: wallStyle }));

    const topY = 42;
    const bottomSlotsY = worldHeight - 50;
    const rows = worldWidth < 500 ? 7 : 8;
    const cols = worldWidth < 500 ? 6 : 7;
    const usableWidth = worldWidth - 52;
    const rowGap = (bottomSlotsY - topY - 60) / rows;
    const colGap = usableWidth / (cols - 1);

    for (let row = 0; row < rows; row += 1) {
      const offset = row % 2 ? colGap / 2 : 0;
      for (let col = 0; col < cols; col += 1) {
        const x = 26 + col * colGap + offset;
        if (x > worldWidth - 26) continue;
        const y = topY + row * rowGap;
        bodies.push(Bodies.circle(x, y, worldWidth < 500 ? 6 : 7, {
          isStatic: true,
          label: 'peg',
          restitution: 1.08,
          friction: 0,
          render: pegStyle
        }));
      }
    }

    const slotWidth = worldWidth / 6;
    for (let i = 1; i < 6; i += 1) {
      const x = slotWidth * i;
      bodies.push(Bodies.rectangle(x, worldHeight - 30, 6, 72, {
        isStatic: true,
        label: 'divider',
        restitution: .72,
        friction: 0,
        render: wallStyle
      }));
    }
    bodies.push(Bodies.rectangle(worldWidth / 2, worldHeight + 12, worldWidth, 24, {
      isStatic: true,
      label: 'floor',
      restitution: .25,
      render: { visible: false }
    }));

    Composite.add(engine.world, bodies);

    Events.on(engine, 'collisionStart', event => {
      const now = performance.now();
      for (const pair of event.pairs) {
        const ball = pair.bodyA.label.startsWith('ball-') ? pair.bodyA : pair.bodyB.label.startsWith('ball-') ? pair.bodyB : null;
        const other = ball === pair.bodyA ? pair.bodyB : pair.bodyA;
        if (!ball || other.label !== 'peg') continue;
        const last = collisionCooldown.get(ball) || 0;
        if (now - last > 42) {
          collisionCooldown.set(ball, now);
          playPeg(ball.speed);
        }
      }
    });

    Events.on(engine, 'afterUpdate', checkSettledBalls);
    Render.run(render);
    Runner.run(runner, engine);
  }

  function makeBall(label, releaseX) {
    const { Bodies, Body, Composite } = Matter;
    const radius = worldWidth < 500 ? 18 : 21;
    const colors = { A: '#ffffff', B: '#f3f6f7', C: '#e8eef0' };
    const body = Bodies.circle(releaseX, 12, radius, {
      label: `ball-${label}`,
      restitution: .94,
      friction: .001,
      frictionStatic: 0,
      frictionAir: .0018,
      density: .00045,
      slop: .01,
      render: {
        fillStyle: colors[label],
        strokeStyle: '#9caab2',
        lineWidth: 1.5
      }
    });
    body.plugin = { letter: label, settled: false, bornAt: performance.now() };
    Body.setVelocity(body, {
      x: (Math.random() - .5) * 5.5,
      y: 1.5 + Math.random() * 1.2
    });
    Body.setAngularVelocity(body, secureRandom(-.125, .125));
    Composite.add(engine.world, body);
    activeBalls.set(label, body);
  }

  function checkSettledBalls() {
    if (!isRunning) return;
    const { Composite } = Matter;
    for (const [label, body] of activeBalls.entries()) {
      if (body.plugin.settled) continue;

      // Safety nudge if an unusually energetic ball stays high too long.
      if (performance.now() - body.plugin.bornAt > 4800 && body.position.y < worldHeight * .72) {
        Matter.Body.applyForce(body, body.position, { x: 0, y: .0006 });
      }

      if (body.position.y > worldHeight - 48 && (body.speed < 1.4 || performance.now() - body.plugin.bornAt > 7000)) {
        body.plugin.settled = true;
        const slotWidth = worldWidth / 6;
        const outcome = Math.max(1, Math.min(6, Math.floor(body.position.x / slotWidth) + 1));
        currentOutcomes[label] = outcome;
        revealBallResult(label, outcome);
        play(sfx.roll);
        completedCount += 1;
        setTimeout(() => {
          Composite.remove(engine.world, body);
          activeBalls.delete(label);
        }, 280);
        if (completedCount === 3) finishRound();
      }
    }
  }

  function initHolderState() {
    const rect = ballHolder.getBoundingClientRect();
    const width = rect.width;
    const starts = [.16, .48, .78];

    holderState = holderBalls.map((element, index) => ({
      element,
      label: element.dataset.ball,
      x: width * starts[index],
      direction: secureRandom() < .5 ? -1 : 1,
      idleSpeed: secureRandom(6.2, 8.4),
      mixSpeed: secureRandom(20, 25.5),
      active: true
    }));

    updateHolderPositions();
  }

  function updateHolderPositions() {
    const width = ballHolder.clientWidth;
    const ballSize = holderBalls[0]?.offsetWidth || 50;
    holderState.forEach(item => {
      item.x = Math.max(ballSize / 2, Math.min(width - ballSize / 2, item.x));
      item.element.style.left = `${item.x - ballSize / 2}px`;
      item.element.style.transform = `rotate(${item.x * 5}deg)`;
    });
  }

  function startContinuousMixer() {
    if (mixerLoopStarted) return;
    mixerLoopStarted = true;

    let last = performance.now();

    const animate = now => {
      const dt = Math.min(2, (now - last) / 16.67);
      last = now;

      const width = ballHolder.clientWidth;
      const radius = (holderBalls[0]?.offsetWidth || 50) / 2;
      const targetMultiplier = mixerMode === 'active' ? 3 : 1;

      holderState.forEach((item, index) => {
        if (!item.active) return;

        const targetSpeed =
          (mixerMode === 'active' ? item.mixSpeed : item.idleSpeed) *
          targetMultiplier;

        const signedTarget = targetSpeed * item.direction;

        if (typeof item.vx !== 'number') {
          item.vx = item.idleSpeed * item.direction;
        }

        // Smooth acceleration and deceleration.
        item.vx += (signedTarget - item.vx) * (mixerMode === 'active' ? .24 : .08);
        item.x += item.vx * dt;

        if (item.x <= radius || item.x >= width - radius) {
          item.x = Math.max(radius, Math.min(width - radius, item.x));
          item.direction *= -1;
          item.vx = Math.abs(item.vx) * item.direction;
        }

        // Small unpredictable variation without steering toward any slot.
        item.vx += secureRandom(-.12, .12);
      });

      updateHolderPositions();
      mixerAnimationId = requestAnimationFrame(animate);
    };

    mixerAnimationId = requestAnimationFrame(animate);
  }

  function setMixerMode(mode) {
    mixerMode = mode;
    mixerSection.classList.toggle('mixing', mode === 'active');

    if (mode !== 'active') {
      stop(sfx.boost);
    }
  }

  function releaseAllBalls() {
    const holderWidth = ballHolder.clientWidth;

    play(sfx.gate);

    holderState.forEach(item => {
      if (!item.active) return;

      const visibleReleaseX = item.x / holderWidth * worldWidth;
      const releaseX = Math.max(
        24,
        Math.min(worldWidth - 24, visibleReleaseX + secureRandom(-2.5, 2.5))
      );

      item.active = false;
      item.element.classList.add('released');
      item.element.style.opacity = '0';
      makeBall(item.label, releaseX);
    });
  }

  async function dropBalls() {
    if (isRunning || !requireMatter()) return;
    isRunning = true;
    completedCount = 0;
    currentOutcomes = { A: null, B: null, C: null };
    activeBalls.clear();
    dropButton.disabled = true;
    dropButton.querySelector('.button-top').textContent = 'MIXING';
    dropButton.querySelector('.button-main').textContent = 'PLEASE WAIT';
    machineStatus.textContent = 'Mixing balls';
    resetResults();
    // Restore the three visible balls without restarting the continuous mixer.
    holderState.forEach(item => {
      item.active = true;
      item.direction = secureRandom() < .5 ? -1 : 1;
      item.idleSpeed = secureRandom(6.2, 8.4);
      item.mixSpeed = secureRandom(20, 25.5);
      item.vx = item.idleSpeed * item.direction;
    });

    holderBalls.forEach(ball => {
      ball.style.opacity = '1';
      ball.classList.remove('released');
    });

    setMixerMode('active');

    // The boost audio controls the timing and is allowed to finish naturally.
    await playBoostAndWait();

    machineStatus.textContent = 'Releasing all balls';
    releaseAllBalls();

    setMixerMode('idle');
    machineStatus.textContent = 'Balls bouncing';
  }

  function revealBallResult(label, value) {
    const column = resultColumns.find(node => node.dataset.result === label);
    column.querySelector('strong').textContent = value;
    column.classList.add('revealed');
  }

  function finishRound() {
    const values = ['A', 'B', 'C'].map(label => currentOutcomes[label]);
    machineStatus.textContent = `Result ${values.join(' · ')}`;
    play(sfx.ding);
    history.unshift(values);
    history = history.slice(0, 8);
    renderHistory();
    round += 1;
    roundLabel.textContent = `Round ${round}`;
    dropButton.disabled = false;
    dropButton.querySelector('.button-top').textContent = 'READY';
    dropButton.querySelector('.button-main').textContent = 'DROP THE BALLS';
    isRunning = false;
    holderState.forEach(item => {
      item.active = true;
      item.direction = secureRandom() < .5 ? -1 : 1;
      item.vx = item.idleSpeed * item.direction;
    });
    holderBalls.forEach(ball => {
      ball.style.opacity = '1';
      ball.classList.remove('released');
    });
    setMixerMode('idle');
  }

  function resetResults() {
    resultColumns.forEach(column => {
      column.querySelector('strong').textContent = '?';
      column.classList.remove('revealed');
    });
  }

  function renderHistory() {
    if (!history.length) {
      historyList.innerHTML = '<p class="empty">No drops yet.</p>';
      return;
    }
    historyList.innerHTML = history.map(values => `
      <div class="history-item" aria-label="A ${values[0]}, B ${values[1]}, C ${values[2]}">
        <span>A${values[0]}</span><span>B${values[1]}</span><span>C${values[2]}</span>
      </div>
    `).join('');
  }


  function wait(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

  dropButton.addEventListener('click', dropBalls);
  soundToggle.addEventListener('click', () => {
    soundOn = !soundOn;
    soundToggle.textContent = soundOn ? '🔊 Sound On' : '🔇 Sound Off';
    soundToggle.setAttribute('aria-pressed', String(soundOn));
    if (!soundOn) {
      stop(sfx.boost);
      stop(sfx.gate);
      stop(sfx.roll);
      stop(sfx.ding);
      sfx.pegs.forEach(stop);
    }
  });
  clearHistoryButton.addEventListener('click', () => {
    history = [];
    renderHistory();
    machineStatus.textContent = 'History cleared';
  });

  let resizeTimer;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
      if (!isRunning) {
        setupPhysics();
        initHolderState();
        if (!mixerLoopStarted) startContinuousMixer();
      }
    }, 180);
  });

  window.addEventListener('load', () => {
    setupPhysics();
    initHolderState();
    startContinuousMixer();
    setMixerMode('idle');
    renderHistory();
  });
})();
